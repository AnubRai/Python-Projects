def rent(movie_list):
    #print(movie_list)
    import datetime
    y = (datetime.datetime.now().year)
    m = (datetime.datetime.now().month)
    d = (datetime.datetime.now().day)
    h = (datetime.datetime.now().hour)
    mn = (datetime.datetime.now().minute)
    date = str(y)+"/"+str(m)+"/"+str(d) #concatinating year month and day 
    time = str(h)+":"+str(mn)  #concatinating hours and minutes

    print(" You may only borrow one Movie ")
    print(" Here are the Movies Available for Renting ")
    for movies in movie_list:
        for movie in movies:
            print(movie,end="\t\t")
        print("\n")
    user_name = input("Enter your name")
    user_number = input("Enter your number")

    movie_id = int(input("Enter the movie you'd like to borrow"))-1 #?????
    #print(movie_id) #???

    file_name = "user_rent/"+user_name + user_number+".txt" #concatinating file name

    movie_list[movie_id][2] = str(int(movie_list[movie_id][2])-1)
    #(movie_list[movie_id][2]) is Quantity after Borrowing

    print('\n')
    print("Name : ",user_name)
    print("Contact Number: ",user_number)
    print("Movie Rented : ",movie_list[0][0])
    print("Total Price of the Movies Rented: ",movie_list[0][1])
    print("Date : ",date)
    print("Time : ",time)
    print('\n')

    
    user_file = open(file_name,"w")
    user_file.write("Name of the customer: "+str(user_name))
    user_file.write("\n")
    user_file.write("Contact number: "+str(user_number))
    user_file.write("\n")
    user_file.write("Name of the Movie Borrowed :"+str(movie_list[0][0]))
    user_file.write("\n")
    user_file.write("Total Cost :"+str(movie_list[0][1]))
    user_file.write("\n")
    user_file.write("Date :"+str(date))
    user_file.write("\n")
    user_file.write("Time :"+str(time))
    user_file.write("\n")
    user_file.close()
    return movie_list

        
            

    

       
        
