def View_List():
        file=open("Movies.txt","r")
        L=[]
        lines=file.readlines()
        for each in lines:
            list1 = each.replace("\n","").split(",")
            L.append(list1)
        file.close()
    return L
main = View_List()  
        
