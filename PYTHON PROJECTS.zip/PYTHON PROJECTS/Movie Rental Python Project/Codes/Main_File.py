import Menu as M
import Display as D
import Rent as R 
import Return as Re

file = open("Movies.txt","r")
contents  = file.readlines()
db = []
for content in contents:
    db.append(content.replace("\n","").split(","))
file.close()

Access = True
while Access == True:
    M.menu()

    try:
        opt = int(input(" Enter your choice : "))
    except:
        print(" INVALID ENTRY ")

    if opt == 1:
        D.Display()
        print("                                    ")
        
    elif opt == 2:
        db = R.rent(db)
        
        #print(db)
        file = open("Movies.txt","w")
        for data in db:
            
            count = 0
            for d in data:
                file.write(d)
                if count<2:
                    file.write(",")
                    count+=1
            file.write("\n")
        file.close()
        
            

    elif opt == 3:
        db =Re.Return(db)
        file = open("Movies.txt","w")
        for data in db:
            count = 0
            for d in data:
                file.write(d)
                if count<2:
                    file.write(",")
                    count+=1
            file.write("\n")
        file.close()
        

    elif opt == 4:
        print("    Thank you.... Visit us Again.... ")
        break;

