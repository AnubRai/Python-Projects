def Display():
    file = open("Movies.txt","r")
    content = file.readlines()
    file.close()
    L=[]
    for each in content:
        L.append(each.replace("\n","").replace("$","").split(","))
    print(" The Following Movies are available for Rent : ")
    print("                                                ")
    print("MOVIE NAME \t \t PRICE \t \t QUANTITY ")
    for i in range(len(L)):
        a = L[i][0]
        b = L[i][1]
        c = L[i][2]
        print(str(a),'\t' ,'\t',str(b),'\t','\t',"$"+str(c))
	
