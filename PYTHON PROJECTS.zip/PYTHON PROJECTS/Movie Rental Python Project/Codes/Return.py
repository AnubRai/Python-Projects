def Return(movie_list):
    #print(movie_list)
    import datetime
    y = (datetime.datetime.now().year)
    m = (datetime.datetime.now().month)
    d = (datetime.datetime.now().day)
    h = (datetime.datetime.now().hour)
    mn = (datetime.datetime.now().minute)
    date = str(y)+"/"+str(m)+"/"+str(d) #concatinating year month and day 
    time = str(h)+":"+str(mn)  #concatinating hours and minutes

    for movies in movie_list:
        for movie in movies:
            print(movie,end="\t\t")
        print("\n")
        
    user_name = input("Enter your name")
    user_number = input("Enter your number")

    movie_id = int(input("Enter the movie id you'd like to return"))-1 #?????
    #print(movie_id) #???

    file_name = "user_return/"+user_name + user_number+".txt" #concatinating file name
    check_name = "user_rent/"+user_name + user_number+".txt"
    movie_list[movie_id][2] = str(int(movie_list[movie_id][2])+1)
    #(movie_list[movie_id][2]) quantity will be added for the book returned

    print('\n')
    print("Name : ",user_name)
    print("Contact Number: ",user_number)
    print("Movie Returned : ",movie_list[0][0])
    print("Total Price of the Movies Rented: ",movie_list[0][1])
    print("Date : ",date)
    print("Time : ",time)
    print('\n')

        
    file = open(file_name,"w")
    file.write("Name of the customer: "+str(user_name))
    file.write("\n")
    file.write("Contact number: "+str(user_number))
    file.write("\n")
    file.write("Name of the Movie Returned:"+str(movie_list[0][0]))
    file.write("\n")
    file.write("Date :"+str(date))
    file.write("\n")
    file.write("Time :"+str(time))
    file.write("\n")
    file.close()

    return movie_list

        
            

    

       
        
